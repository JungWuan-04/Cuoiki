import 'package:flutter/material.dart';
import 'compose_email_page.dart'; // Nhớ import trang soạn thư

class EmailDetailPage extends StatelessWidget {
  final String sender;
  final String subject;
  final String message;
  final String time;

  const EmailDetailPage({
    Key? key,
    required this.sender,
    required this.subject,
    required this.message,
    required this.time,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chi tiết Email'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Text('Người gửi: $sender',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 12),
            Text('Tiêu đề: $subject',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const Divider(height: 24),
            Text(message, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 24),
            Text('Thời gian: $time',
                style: const TextStyle(color: Colors.grey, fontSize: 14)),
            const SizedBox(height: 32),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.reply),
                    label: const Text('Trả lời'),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ComposeEmailPage(
                            recipient: sender,
                            subject: 'Re: $subject',
                            body: '\n\n--- Nội dung trả lời ---\n$message',
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.forward),
                    label: const Text('Chuyển tiếp'),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ComposeEmailPage(
                            subject: 'Fwd: $subject',
                            body: '\n\n--- Nội dung chuyển tiếp ---\n$message',
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
