import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ComposeEmailPage extends StatefulWidget {
  final String? recipient;
  final String? subject;
  final String? body;

  const ComposeEmailPage({Key? key, this.recipient, this.subject, this.body})
      : super(key: key);

  @override
  State<ComposeEmailPage> createState() => _ComposeEmailPageState();
}

class _ComposeEmailPageState extends State<ComposeEmailPage> {
  late TextEditingController _recipientController;
  late TextEditingController _subjectController;
  late TextEditingController _contentController;

  String? _attachedFileName;
  bool _isSending = false;

  @override
  void initState() {
    super.initState();
    _recipientController = TextEditingController(text: widget.recipient ?? '');
    _subjectController = TextEditingController(text: widget.subject ?? '');
    _contentController = TextEditingController(text: widget.body ?? '');
    _loadDraft();
  }

  Future<void> _loadDraft() async {
    final prefs = await SharedPreferences.getInstance();

    // Chỉ load draft khi các trường hiện tại rỗng (để không ghi đè dữ liệu truyền vào)
    if (_recipientController.text.isEmpty &&
        _subjectController.text.isEmpty &&
        _contentController.text.isEmpty) {
      final draftRecipient = prefs.getString('draft_recipient');
      final draftSubject = prefs.getString('draft_subject');
      final draftContent = prefs.getString('draft_content');
      final draftAttachedFile = prefs.getString('draft_attached_file');

      setState(() {
        _recipientController.text = draftRecipient ?? '';
        _subjectController.text = draftSubject ?? '';
        _contentController.text = draftContent ?? '';
        _attachedFileName = draftAttachedFile;
      });
    }
  }

  Future<void> _saveDraft() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('draft_recipient', _recipientController.text);
    await prefs.setString('draft_subject', _subjectController.text);
    await prefs.setString('draft_content', _contentController.text);
    if (_attachedFileName != null) {
      await prefs.setString('draft_attached_file', _attachedFileName!);
    } else {
      await prefs.remove('draft_attached_file');
    }
  }

  Future<void> _clearDraft() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('draft_recipient');
    await prefs.remove('draft_subject');
    await prefs.remove('draft_content');
    await prefs.remove('draft_attached_file');
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.image);
    if (result != null && result.files.isNotEmpty) {
      setState(() {
        _attachedFileName = result.files.single.name;
      });
    }
  }

  void _sendEmail() async {
    setState(() {
      _isSending = true;
    });

    // Giả lập gửi email
    await Future.delayed(const Duration(seconds: 1));
    await _clearDraft();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Đã gửi thành công')),
    );
    Navigator.pop(context);
  }

  Future<bool> _onWillPop() async {
    if (_isSending) return true;

    if (_recipientController.text.isNotEmpty ||
        _subjectController.text.isNotEmpty ||
        _contentController.text.isNotEmpty ||
        _attachedFileName != null) {
      await _saveDraft();
    }
    return true;
  }

  @override
  void dispose() {
    _recipientController.dispose();
    _subjectController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Soạn Email'),
          actions: [
            IconButton(
              icon: const Icon(Icons.send),
              onPressed: _isSending ? null : _sendEmail,
            )
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextField(
                controller: _recipientController,
                decoration: const InputDecoration(
                  labelText: 'Người nhận',
                  hintText: 'example@gmail.com',
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _subjectController,
                decoration: const InputDecoration(labelText: 'Tiêu đề'),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: TextField(
                  controller: _contentController,
                  decoration: const InputDecoration(labelText: 'Nội dung'),
                  maxLines: null,
                  expands: true,
                  keyboardType: TextInputType.multiline,
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  ElevatedButton.icon(
                    onPressed: _pickFile,
                    icon: const Icon(Icons.attach_file),
                    label: const Text('Đính kèm'),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _attachedFileName ?? 'Chưa đính kèm file',
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: _isSending ? null : _sendEmail,
                child: _isSending
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('Gửi'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
