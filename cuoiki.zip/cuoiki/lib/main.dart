import 'package:flutter/material.dart';
import 'login_page.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Simple Gmail Clone',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),  // Bạn có thể đổi theme nếu muốn
      home: const LoginPage(),
    );
  }
  
}