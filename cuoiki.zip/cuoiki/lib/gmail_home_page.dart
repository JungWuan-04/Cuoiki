import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'compose_email_page.dart';  // import thêm ở đầu file
import 'email_detail_page.dart';
import 'dart:async';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';





class GmailHomePage extends StatefulWidget {
  const GmailHomePage({Key? key}) : super(key: key);

  @override
  State<GmailHomePage> createState() => _GmailHomePageState();
}

class _GmailHomePageState extends State<GmailHomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Danh sách gốc emails
  final List<Map<String, dynamic>> emails = [
    {
      'sender': 'Gamefound',
      'subject': 'New comment reply',
      'message': "There’s a new reply to your comment.",
      'time': '6:13 AM',
      'avatar': 'G',
      'isStarred': false,
      'label': 'Primary',
    },
    {
      'sender': 'Gamefound',
      'subject': 'Update 24 in Lands of Evershade',
      'message': "Pledge Manager is OPEN! / External TESTING...",
      'time': '2:41 AM',
      'avatar': 'G',
      'isStarred': false,
      'label': 'Primary',
    },
    {
      'sender': 'BoardGameTables.com',
      'subject': 'A shipment from order #241222 is on the way',
      'message': "🚗  Shipped",
      'time': '28 Feb',
      'avatar': 'B',
      'isStarred': false,
      'label': 'Promotions',
    },
    {
      'sender': 'Gamefound',
      'subject': 'AR Next: Coming to Gamefound in 2025',
      'message': "War, Agriculture and zombies See all AR Next...",
      'time': '28 Feb',
      'avatar': 'G',
      'isStarred': false,
      'label': 'Updates',
    },
    {
      'sender': 'Gamefound',
      'subject': 'Update 18 in Puerto Rico Special Edition',
      'message': "Development news / New artwork revealed!",
      'time': '27 Feb',
      'avatar': 'G',
      'isStarred': false,
      'label': 'Updates',
    },
    {
      'sender': 'cardservicedesk',
      'subject': 'SAO KÉ TÍCH ĐIỂM HOÀN TIÊN MASTERCARD...',
      'message': "Kính gửi: Quý khách hàng Ngân hàng TMCP H...",
      'time': '22 Feb',
      'avatar': 'C',
      'isStarred': false,
      'label': 'Social',
    },
    {
      'sender': 'Miniature Market',
      'subject': 'A little gift for your next game n°',
      'message': "Limited-time deal: \$10 off when",
      'time': '22 Feb',
      'avatar': 'M',
      'isStarred': false,
      'label': 'Promotions',
    },
  ];

  // Label list
  final List<String> labels = [
    'All',
    'Primary',
    'Social',
    'Promotions',
    'Updates',
  ];

  // Biến lưu nhãn hiện tại được chọn để lọc
  String selectedLabel = 'All';

  // Danh sách email sau lọc (cả theo search và label)
  List<Map<String, dynamic>> filteredEmails = [];

  // Controller cho TextField search
  final TextEditingController _searchController = TextEditingController();

  @override
void initState() {
  super.initState();

  // Khởi tạo filteredEmails là toàn bộ emails lúc đầu
  filteredEmails = List.from(emails);

  // Lắng nghe thay đổi search
  _searchController.addListener(_filterEmails);

  // Khởi tạo notifications plugin
  flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  const initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  const initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
  );

  flutterLocalNotificationsPlugin.initialize(initializationSettings);

  // Bắt đầu giả lập nhận email mới mỗi 10 giây
  _emailTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
    _simulateReceiveEmail();
  });
}

  @override
  void dispose() {
    _searchController.dispose();
    _emailTimer?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  void _filterEmails() {
    final query = _searchController.text.toLowerCase();

    setState(() {
      filteredEmails = emails.where((email) {
        final sender = email['sender'].toString().toLowerCase();
        final subject = email['subject'].toString().toLowerCase();
        final message = email['message'].toString().toLowerCase();
        final label = email['label'].toString();

        // Kiểm tra nhãn nếu không phải "All"
        bool matchesLabel = selectedLabel == 'All' || label == selectedLabel;

        bool matchesSearch = sender.contains(query) ||
            subject.contains(query) ||
            message.contains(query);

        return matchesLabel && (query.isEmpty || matchesSearch);
      }).toList();
    });
  }

  Color getAvatarColor(String avatar) {
    final Map<String, Color> colorMap = {
      'G': const Color.fromRGBO(160, 66, 244, 1),
      'B': const Color.fromRGBO(251, 187, 1, 1),
      'C': const Color.fromRGBO(52, 167, 83, 1),
      'M': const Color.fromRGBO(233, 30, 99, 1),
    };

    String firstChar = avatar[0].toUpperCase();
    return colorMap[firstChar] ?? Colors.grey;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawerEnableOpenDragGesture: true,
      drawer: _buildDrawer(),
      floatingActionButton: _buildFAB(),
      bottomNavigationBar: _buildBottomNavigationBar(),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0), // Căn lề 2 bên
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSearchBar(),
              _buildLabelManagement(),  // <-- chỗ thêm mới
              _buildLabelSection(),
              const SizedBox(height: 20),
              _buildEmailList(),
            ],
          ),
        ),
      ),
    );
  }

  // Widget cho hàng icon quản lý nhãn
  Widget _buildLabelManagement() {
    return SizedBox(
      height: 50,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: labels.length,
        itemBuilder: (context, index) {
          final label = labels[index];
          final isSelected = label == selectedLabel;

          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: ChoiceChip(
              label: Text(label,
                  style: TextStyle(
                      color: isSelected ? Colors.white : Colors.grey[400],
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
              selected: isSelected,
              selectedColor: Colors.blue,
              backgroundColor: Colors.grey[800],
              onSelected: (selected) {
                setState(() {
                  selectedLabel = selected ? label : 'All';
                  _filterEmails();
                });
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      height: 48.0,
      margin: const EdgeInsets.only(top: 10, bottom: 16),
      padding: const EdgeInsets.symmetric(horizontal: 8), // padding 2 bên
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(8),
        boxShadow: const [
          BoxShadow(
            color: Color.fromRGBO(0, 0, 0, 0.2),
            blurRadius: 5,
            offset: Offset(0, 0),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(
            width: 40,
            height: 40,
            child: IconButton(
              padding: EdgeInsets.zero,
              icon: const Icon(Icons.menu, size: 28),
              onPressed: () {
                final scaffoldState = _scaffoldKey.currentState;
                if (scaffoldState != null) {
                  if (scaffoldState.isDrawerOpen) {
                    Navigator.of(context).pop();
                  } else {
                    scaffoldState.openDrawer();
                  }
                }
              },
            ),
          ),
          const SizedBox(width: 8),
          // Thay Text tĩnh bằng TextField cho tìm kiếm
          Expanded(
            child: TextField(
              controller: _searchController,
              style: const TextStyle(fontSize: 16, color: Colors.white),
              cursorColor: Colors.white,
              decoration: const InputDecoration(
                hintText: 'Search in mail',
                hintStyle: TextStyle(color: Colors.grey),
                border: InputBorder.none,
              ),
            ),
          ),
          SizedBox(
            width: 40,
            height: 40,
            child: IconButton(
              padding: EdgeInsets.zero,
              icon: ClipRRect(
                borderRadius: BorderRadius.circular(100),
                child: Image.asset(
                  'assets/avatar.jpg',
                  width: 30,
                  height: 30,
                  fit: BoxFit.cover,
                ),
              ),
              onPressed: () {},
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLabelSection() {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: const EdgeInsets.only(left: 0),
        child: Text(
          selectedLabel == 'All' ? 'Updates' : selectedLabel,
          style: const TextStyle(
            fontSize: 13,
            color: Colors.grey,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }

  Widget _buildEmailList() {
    // Sắp xếp emails, sao vàng lên trên cùng
    filteredEmails.sort((a, b) {
      if (a['isStarred'] == b['isStarred']) return 0;
      if (a['isStarred'] == true) return -1;
      return 1;
    });

    return Expanded(
      child: ListView(
        children: filteredEmails.map((email) {
          return ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 0),
            visualDensity: VisualDensity.compact,
            titleAlignment: ListTileTitleAlignment.top,
            leading: Padding(
              padding: const EdgeInsets.only(top: 8),
              child: CircleAvatar(
                backgroundColor: getAvatarColor(email['avatar']!),
                child: Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    email['avatar']!,
                    style: const TextStyle(color: Colors.white, fontSize: 20),
                    textAlign: TextAlign.center,
                    strutStyle: StrutStyle(forceStrutHeight: true),
                  ),
                ),
              ),
            ),
            title: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(email['sender']!,
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 16)),
                      const SizedBox(height: 4),
                      Text(email['subject']!,
                          style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 13,
                              letterSpacing: 0.1)),
                      const SizedBox(height: 2),
                      Text(email['message']!,
                          style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 14,
                              wordSpacing: -0.8,
                              letterSpacing: -0.4)),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(email['time']!,
                        style:
                            const TextStyle(color: Colors.grey, fontSize: 13)),
                    const SizedBox(height: 30),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Transform.scale(
                            scale: 0.5,
                            child: const Icon(Icons.more_horiz,
                                color: Colors.grey),
                          ),
                          constraints: const BoxConstraints(),
                          padding: const EdgeInsets.fromLTRB(0, 7.5, 0, 0),
                          onPressed: () {},
                        ),
                        const SizedBox(width: 5),
                        IconButton(
                          icon: Icon(
                            email['isStarred'] ? Icons.star : Icons.star_border,
                            color:
                                email['isStarred'] ? Colors.yellow : Colors.grey,
                          ),
                          constraints: const BoxConstraints(),
                          padding: EdgeInsets.zero,
                          onPressed: () {
                            setState(() {
                              email['isStarred'] = !(email['isStarred'] as bool);
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EmailDetailPage(
                    sender: email['sender']!,
                    subject: email['subject']!,
                    message: email['message']!,
                    time: email['time']!,
                  ),
                ),
              );
            },
          );
        }).toList(),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          SizedBox(
            height: 90,
            child: DrawerHeader(
              child: Padding(
                padding: const EdgeInsets.only(left: 16),
                child: Row(
                  children: [
                    SvgPicture.asset(
                      'assets/image.png',
                      width: 20,
                      height: 16,
                    ),
                    const SizedBox(width: 8),
                    const Text('Gmail',
                        style: TextStyle(color: Colors.white, fontSize: 20)),
                  ],
                ),
              ),
            ),
          ),
          ListTileTheme(
            dense: true,
            contentPadding: const EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              children: [
                _buildDrawerItem(Icons.all_inbox, 'All inboxes'),
                _buildDivider(),
                _buildDrawerItem(Icons.inbox, 'Primary'),
                _buildDrawerItem(Icons.people, 'Social'),
                _buildDrawerItem(Icons.local_offer_outlined, 'Promotions'),
                _buildDrawerItem(Icons.info_outline, 'Updates'),
                _buildDrawerItem(Icons.forum_outlined, 'Forums'),
                _buildDivider(),
                _buildDrawerItem(Icons.star_border, 'Starred'),
                _buildDrawerItem(Icons.access_time, 'Snoozed'),
                _buildDrawerItem(Icons.label_important_outline, 'Important'),
                _buildDrawerItem(Icons.send_outlined, 'Sent'),
                _buildDrawerItem(Icons.schedule_send_outlined, 'Scheduled'),
                _buildDrawerItem(Icons.outbox_outlined, 'Outbox'),
                _buildDrawerItem(Icons.drafts_outlined, 'Drafts'),
                _buildDrawerItem(Icons.mail_outline, 'All mail'),
                _buildDrawerItem(Icons.cancel_outlined, 'Spam'),
                _buildDrawerItem(Icons.delete_outline, 'Bin'),
                _buildDivider(),
                _buildDrawerItem(Icons.settings_outlined, 'Settings'),
                _buildDrawerItem(Icons.help_outline, 'Help & feedback'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem(IconData icon, String title) {
    return ListTile(
      dense: true,
      minLeadingWidth: 0,
      horizontalTitleGap: 32,
      visualDensity: VisualDensity.compact,
      leading: Icon(icon, color: Colors.grey[400], size: 20),
      title: Text(
        title,
        style: const TextStyle(fontSize: 15, color: Colors.grey),
      ),
      onTap: () {},
    );
  }

  Widget _buildDivider() {
    return Divider(color: Colors.grey[800], thickness: 1);
  }

  Widget _buildFAB() {
  return Stack(
    children: [
      FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ComposeEmailPage()),
          );
          if (result != null && result is Map<String, dynamic>) {
            setState(() {
              emails.insert(0, result);
              _filterEmails();
              newEmailCount = 0; // Reset badge nếu tạo email mới
            });
          }
        },
        backgroundColor: const Color.fromRGBO(65, 91, 245, 1),
        child: const Icon(Icons.edit, color: Colors.white),
      ),
      if (newEmailCount > 0)
        Positioned(
          right: 0,
          top: 0,
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: const BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
            ),
            constraints: const BoxConstraints(
              minWidth: 18,
              minHeight: 18,
            ),
            child: Text(
              '$newEmailCount',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        )
    ],
  );
}


  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      backgroundColor: const Color.fromRGBO(40, 40, 40, 1),
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.mail), label: 'Mail'),
        BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
        BottomNavigationBarItem(icon: Icon(Icons.groups), label: 'Spaces'),
        BottomNavigationBarItem(icon: Icon(Icons.call), label: 'Meet'),
      ],
      currentIndex: 0,
      selectedItemColor: Colors.white,
      unselectedItemColor: Colors.grey,
      onTap: (index) {},
      type: BottomNavigationBarType.fixed,
    );
  }

  late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;
Timer? _emailTimer;

// Đếm email mới chưa xem để hiện badge (nếu muốn)
int newEmailCount = 0;
  void _simulateReceiveEmail() {
  final newEmail = {
    'sender': 'NewSender${DateTime.now().second}',
    'subject': 'New subject at ${DateTime.now().hour}:${DateTime.now().minute}:${DateTime.now().second}',
    'message': 'This is a new email message received.',
    'time': _formatTime(DateTime.now()),
    'avatar': 'N',
    'isStarred': false,
    'label': 'Primary',
  };

  setState(() {
    emails.insert(0, newEmail); // Thêm email mới lên đầu
    newEmailCount++; // Tăng badge email mới
    _filterEmails(); // Lọc lại danh sách hiển thị
  });

  _showNotification(newEmail);
}
  String _formatTime(DateTime time) {
  String twoDigits(int n) => n.toString().padLeft(2, '0');
  final hour = twoDigits(time.hour);
  final minute = twoDigits(time.minute);
  return '$hour:$minute';
}

  Future<void> _showNotification(Map<String, dynamic> email) async {
  const androidPlatformChannelSpecifics = AndroidNotificationDetails(
    'new_email_channel',
    'New Emails',
    channelDescription: 'Notification channel for new emails',
    importance: Importance.max,
    priority: Priority.high,
    ticker: 'ticker',
  );
  const platformChannelSpecifics =
      NotificationDetails(android: androidPlatformChannelSpecifics);

  await flutterLocalNotificationsPlugin.show(
    0,
    'New email from ${email['sender']}',
    '${email['subject']} - Received at ${email['time']}',
    platformChannelSpecifics,
    payload: 'email_payload',
  );
}
}

